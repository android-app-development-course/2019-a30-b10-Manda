package com.example.manda.Rating;

public class cc1 {

}
